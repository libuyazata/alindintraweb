// import { NumbersOnlyDirective } from './number-only.directive';

describe('NumberOnlyDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new NumbersOnlyDirective();
  //   expect(directive).toBeTruthy();
  // });
});
