// import { DecimalNumberDirective } from './decimal-number.directive';

describe('DecimalNumberDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new DecimalNumberDirective();
  //   expect(directive).toBeTruthy();
  // });
});
