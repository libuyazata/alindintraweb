import { Injectable } from '@angular/core';
//import { Observable } from 'rxjs/Observable';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class MonthViewService {

  constructor() {
      
  } 

}
